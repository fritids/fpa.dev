CREATE TABLE IF NOT EXISTS `wp_m_membership_rules` (
  `level_id` bigint(20) NOT NULL DEFAULT '0',
  `rule_ive` varchar(20) NOT NULL DEFAULT '',
  `rule_area` varchar(20) NOT NULL DEFAULT '',
  `rule_value` text,
  `rule_order` int(11) DEFAULT '0',
  PRIMARY KEY (`level_id`,`rule_ive`,`rule_area`),
  KEY `rule_area` (`rule_area`),
  KEY `rule_ive` (`rule_ive`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_membership_rules`;
 
INSERT INTO `wp_m_membership_rules` VALUES ('3', 'positive', 'categories', 'a:2:{i:0;s:1:"8";i:1;s:1:"1";}', '3'); 
INSERT INTO `wp_m_membership_rules` VALUES ('3', 'positive', 'comments', 'a:1:{i:0;s:3:"yes";}', '1'); 
INSERT INTO `wp_m_membership_rules` VALUES ('3', 'positive', 'menu', 'a:24:{i:0;s:3:"284";i:1;s:3:"287";i:2;s:3:"288";i:3;s:3:"286";i:4;s:3:"285";i:5;s:2:"45";i:6;s:2:"50";i:7;s:2:"62";i:8;s:2:"70";i:9;s:2:"51";i:10;s:3:"151";i:11;s:3:"152";i:12;s:2:"66";i:13;s:2:"68";i:14;s:3:"134";i:15;s:2:"47";i:16;s:2:"73";i:17;s:2:"49";i:18;s:2:"67";i:19;s:2:"44";i:20;s:2:"48";i:21;s:2:"63";i:22;s:2:"43";i:23;s:2:"46";}', '6'); 
INSERT INTO `wp_m_membership_rules` VALUES ('3', 'positive', 'more', 'a:1:{i:0;s:3:"yes";}', '2'); 
INSERT INTO `wp_m_membership_rules` VALUES ('3', 'positive', 'pages', 'a:21:{i:0;s:3:"247";i:1;s:3:"236";i:2;s:3:"233";i:3;s:3:"231";i:4;s:3:"229";i:5;s:3:"190";i:6;s:3:"186";i:7;s:2:"71";i:8;s:2:"69";i:9;s:2:"60";i:10;s:2:"58";i:11;s:2:"56";i:12;s:2:"54";i:13;s:2:"52";i:14;s:2:"28";i:15;s:2:"23";i:16;s:2:"21";i:17;s:2:"16";i:18;s:2:"14";i:19;s:2:"13";i:20;s:1:"9";}', '4'); 
INSERT INTO `wp_m_membership_rules` VALUES ('3', 'positive', 'posts', 'a:6:{i:0;s:3:"141";i:1;s:3:"139";i:2;s:3:"137";i:3;s:2:"84";i:4;s:2:"82";i:5;s:1:"1";}', '5'); 
INSERT INTO `wp_m_membership_rules` VALUES ('4', 'positive', 'categories', 'a:2:{i:0;s:1:"8";i:1;s:1:"1";}', '3'); 
INSERT INTO `wp_m_membership_rules` VALUES ('4', 'positive', 'comments', 'a:1:{i:0;s:3:"yes";}', '1'); 
INSERT INTO `wp_m_membership_rules` VALUES ('4', 'positive', 'menu', 'a:24:{i:0;s:3:"284";i:1;s:3:"287";i:2;s:3:"288";i:3;s:3:"286";i:4;s:3:"285";i:5;s:2:"45";i:6;s:2:"50";i:7;s:2:"62";i:8;s:2:"70";i:9;s:2:"51";i:10;s:3:"151";i:11;s:3:"152";i:12;s:2:"66";i:13;s:2:"68";i:14;s:3:"134";i:15;s:2:"47";i:16;s:2:"73";i:17;s:2:"49";i:18;s:2:"67";i:19;s:2:"44";i:20;s:2:"48";i:21;s:2:"63";i:22;s:2:"43";i:23;s:2:"46";}', '6'); 
INSERT INTO `wp_m_membership_rules` VALUES ('4', 'positive', 'more', 'a:1:{i:0;s:3:"yes";}', '2'); 
INSERT INTO `wp_m_membership_rules` VALUES ('4', 'positive', 'pages', 'a:21:{i:0;s:3:"247";i:1;s:3:"236";i:2;s:3:"233";i:3;s:3:"231";i:4;s:3:"229";i:5;s:3:"190";i:6;s:3:"186";i:7;s:2:"71";i:8;s:2:"69";i:9;s:2:"60";i:10;s:2:"58";i:11;s:2:"56";i:12;s:2:"54";i:13;s:2:"52";i:14;s:2:"28";i:15;s:2:"23";i:16;s:2:"21";i:17;s:2:"16";i:18;s:2:"14";i:19;s:2:"13";i:20;s:1:"9";}', '4'); 
INSERT INTO `wp_m_membership_rules` VALUES ('4', 'positive', 'posts', 'a:6:{i:0;s:3:"141";i:1;s:3:"139";i:2;s:3:"137";i:3;s:2:"84";i:4;s:2:"82";i:5;s:1:"1";}', '5'); 
INSERT INTO `wp_m_membership_rules` VALUES ('5', 'positive', 'categories', 'a:2:{i:0;s:1:"8";i:1;s:1:"1";}', '3'); 
INSERT INTO `wp_m_membership_rules` VALUES ('5', 'positive', 'comments', 'a:1:{i:0;s:3:"yes";}', '1'); 
INSERT INTO `wp_m_membership_rules` VALUES ('5', 'positive', 'menu', 'a:24:{i:0;s:3:"284";i:1;s:3:"287";i:2;s:3:"288";i:3;s:3:"286";i:4;s:3:"285";i:5;s:2:"45";i:6;s:2:"50";i:7;s:2:"62";i:8;s:2:"70";i:9;s:2:"51";i:10;s:3:"151";i:11;s:3:"152";i:12;s:2:"66";i:13;s:2:"68";i:14;s:3:"134";i:15;s:2:"47";i:16;s:2:"73";i:17;s:2:"49";i:18;s:2:"67";i:19;s:2:"44";i:20;s:2:"48";i:21;s:2:"63";i:22;s:2:"43";i:23;s:2:"46";}', '6'); 
INSERT INTO `wp_m_membership_rules` VALUES ('5', 'positive', 'more', 'a:1:{i:0;s:3:"yes";}', '2'); 
INSERT INTO `wp_m_membership_rules` VALUES ('5', 'positive', 'pages', 'a:21:{i:0;s:3:"247";i:1;s:3:"236";i:2;s:3:"233";i:3;s:3:"231";i:4;s:3:"229";i:5;s:3:"190";i:6;s:3:"186";i:7;s:2:"71";i:8;s:2:"69";i:9;s:2:"60";i:10;s:2:"58";i:11;s:2:"56";i:12;s:2:"54";i:13;s:2:"52";i:14;s:2:"28";i:15;s:2:"23";i:16;s:2:"21";i:17;s:2:"16";i:18;s:2:"14";i:19;s:2:"13";i:20;s:1:"9";}', '4'); 
INSERT INTO `wp_m_membership_rules` VALUES ('5', 'positive', 'posts', 'a:6:{i:0;s:3:"141";i:1;s:3:"139";i:2;s:3:"137";i:3;s:2:"84";i:4;s:2:"82";i:5;s:1:"1";}', '5'); 
INSERT INTO `wp_m_membership_rules` VALUES ('6', 'positive', 'categories', 'a:2:{i:0;s:1:"8";i:1;s:1:"1";}', '3'); 
INSERT INTO `wp_m_membership_rules` VALUES ('6', 'positive', 'comments', 'a:1:{i:0;s:3:"yes";}', '1'); 
INSERT INTO `wp_m_membership_rules` VALUES ('6', 'positive', 'menu', 'a:24:{i:0;s:3:"284";i:1;s:3:"287";i:2;s:3:"288";i:3;s:3:"286";i:4;s:3:"285";i:5;s:2:"45";i:6;s:2:"50";i:7;s:2:"62";i:8;s:2:"70";i:9;s:2:"51";i:10;s:3:"151";i:11;s:3:"152";i:12;s:2:"66";i:13;s:2:"68";i:14;s:3:"134";i:15;s:2:"47";i:16;s:2:"73";i:17;s:2:"49";i:18;s:2:"67";i:19;s:2:"44";i:20;s:2:"48";i:21;s:2:"63";i:22;s:2:"43";i:23;s:2:"46";}', '6'); 
INSERT INTO `wp_m_membership_rules` VALUES ('6', 'positive', 'more', 'a:1:{i:0;s:3:"yes";}', '2'); 
INSERT INTO `wp_m_membership_rules` VALUES ('6', 'positive', 'pages', 'a:21:{i:0;s:3:"247";i:1;s:3:"236";i:2;s:3:"233";i:3;s:3:"231";i:4;s:3:"229";i:5;s:3:"190";i:6;s:3:"186";i:7;s:2:"71";i:8;s:2:"69";i:9;s:2:"60";i:10;s:2:"58";i:11;s:2:"56";i:12;s:2:"54";i:13;s:2:"52";i:14;s:2:"28";i:15;s:2:"23";i:16;s:2:"21";i:17;s:2:"16";i:18;s:2:"14";i:19;s:2:"13";i:20;s:1:"9";}', '4'); 
INSERT INTO `wp_m_membership_rules` VALUES ('6', 'positive', 'posts', 'a:6:{i:0;s:3:"141";i:1;s:3:"139";i:2;s:3:"137";i:3;s:2:"84";i:4;s:2:"82";i:5;s:1:"1";}', '5');
# --------------------------------------------------------

