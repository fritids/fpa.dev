CREATE TABLE IF NOT EXISTS `wp_p2p` (
  `p2p_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p2p_from` bigint(20) unsigned NOT NULL,
  `p2p_to` bigint(20) unsigned NOT NULL,
  `p2p_type` varchar(44) NOT NULL DEFAULT '',
  PRIMARY KEY (`p2p_id`),
  KEY `p2p_from` (`p2p_from`),
  KEY `p2p_to` (`p2p_to`),
  KEY `p2p_type` (`p2p_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_p2p`;
 
INSERT INTO `wp_p2p` VALUES ('1', '1', '123', 'players_events'); 
INSERT INTO `wp_p2p` VALUES ('2', '1133', '123', 'players_events'); 
INSERT INTO `wp_p2p` VALUES ('3', '1130', '123', 'players_events'); 
INSERT INTO `wp_p2p` VALUES ('4', '1', '123', 'player_to_event'); 
INSERT INTO `wp_p2p` VALUES ('5', '123', '2422', 'event_to_player'); 
INSERT INTO `wp_p2p` VALUES ('6', '2422', '123', 'player_to_event');
# --------------------------------------------------------

