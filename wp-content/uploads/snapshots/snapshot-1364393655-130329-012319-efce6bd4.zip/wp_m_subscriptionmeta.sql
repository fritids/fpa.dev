CREATE TABLE IF NOT EXISTS `wp_m_subscriptionmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub_id` bigint(20) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_value` text,
  `meta_stamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_id` (`sub_id`,`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_subscriptionmeta`;
 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('1', '1', 'joining_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('2', '1', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('3', '2', 'joining_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('4', '2', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('9', '3', 'joining_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('10', '3', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('11', '4', 'joining_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('12', '4', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('13', '5', 'joining_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('14', '5', 'leaving_ping', '', '');
# --------------------------------------------------------

