CREATE TABLE IF NOT EXISTS `wp_m_membership_rules` (
  `level_id` bigint(20) NOT NULL DEFAULT '0',
  `rule_ive` varchar(20) NOT NULL DEFAULT '',
  `rule_area` varchar(20) NOT NULL DEFAULT '',
  `rule_value` text,
  `rule_order` int(11) DEFAULT '0',
  PRIMARY KEY (`level_id`,`rule_ive`,`rule_area`),
  KEY `rule_area` (`rule_area`),
  KEY `rule_ive` (`rule_ive`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_membership_rules`;

# --------------------------------------------------------

