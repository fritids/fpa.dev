CREATE TABLE IF NOT EXISTS `wp_m_ping_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ping_id` bigint(20) DEFAULT NULL,
  `ping_sent` timestamp NULL DEFAULT NULL,
  `ping_info` text,
  `ping_return` text,
  PRIMARY KEY (`id`),
  KEY `ping_id` (`ping_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_ping_history`;

# --------------------------------------------------------

