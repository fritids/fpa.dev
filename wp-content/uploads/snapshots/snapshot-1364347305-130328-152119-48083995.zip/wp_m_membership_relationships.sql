CREATE TABLE IF NOT EXISTS `wp_m_membership_relationships` (
  `rel_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT '0',
  `sub_id` bigint(20) DEFAULT '0',
  `level_id` bigint(20) DEFAULT '0',
  `startdate` datetime DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `order_instance` bigint(20) DEFAULT '0',
  `usinggateway` varchar(50) DEFAULT 'admin',
  PRIMARY KEY (`rel_id`),
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  KEY `usinggateway` (`usinggateway`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_membership_relationships`;
 
INSERT INTO `wp_m_membership_relationships` VALUES ('1', '1', '2', '3', '2013-03-27 17:15:00', '2013-03-27 17:15:00', '2013-04-16 17:15:00', '1', 'paypalexpress'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('2', '2', '2', '3', '2013-03-27 17:55:43', '2013-03-27 17:55:43', '2013-04-16 17:55:43', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('3', '3', '2', '3', '2013-03-28 00:23:35', '2013-03-28 00:23:35', '2013-04-17 00:23:35', '1', 'admin');
# --------------------------------------------------------

