CREATE TABLE IF NOT EXISTS `wp_m_membership_news` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `newsitem` text,
  `newsdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_membership_news`;
 
INSERT INTO `wp_m_membership_news` VALUES ('1', '<strong>Rising Artistry</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-27 17:15:00'); 
INSERT INTO `wp_m_membership_news` VALUES ('2', '<strong>themarblery</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-27 17:55:43'); 
INSERT INTO `wp_m_membership_news` VALUES ('3', '<strong>HillBillyJones</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 00:23:35');
# --------------------------------------------------------

