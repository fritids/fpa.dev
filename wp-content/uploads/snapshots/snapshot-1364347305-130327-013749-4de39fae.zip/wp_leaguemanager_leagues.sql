CREATE TABLE IF NOT EXISTS `wp_leaguemanager_leagues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `settings` longtext NOT NULL,
  `seasons` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_leaguemanager_leagues`;

# --------------------------------------------------------

