CREATE TABLE IF NOT EXISTS `wp_leaguemanager_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(50) NOT NULL DEFAULT '&#8226;',
  `title` varchar(100) NOT NULL DEFAULT '',
  `logo` varchar(150) NOT NULL DEFAULT '',
  `website` varchar(255) NOT NULL DEFAULT '',
  `coach` varchar(100) NOT NULL DEFAULT '',
  `stadium` varchar(150) NOT NULL DEFAULT '',
  `home` tinyint(1) NOT NULL DEFAULT '0',
  `points_plus` float NOT NULL DEFAULT '0',
  `points_minus` float NOT NULL DEFAULT '0',
  `points2_plus` int(11) NOT NULL DEFAULT '0',
  `points2_minus` int(11) NOT NULL DEFAULT '0',
  `add_points` int(11) NOT NULL DEFAULT '0',
  `done_matches` int(11) NOT NULL DEFAULT '0',
  `won_matches` int(11) NOT NULL DEFAULT '0',
  `draw_matches` int(11) NOT NULL DEFAULT '0',
  `lost_matches` int(11) NOT NULL DEFAULT '0',
  `diff` int(11) NOT NULL DEFAULT '0',
  `group` varchar(30) NOT NULL DEFAULT '',
  `league_id` int(11) NOT NULL,
  `season` varchar(255) NOT NULL DEFAULT '',
  `rank` int(11) NOT NULL DEFAULT '0',
  `roster` longtext NOT NULL,
  `custom` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_leaguemanager_teams`;

# --------------------------------------------------------

