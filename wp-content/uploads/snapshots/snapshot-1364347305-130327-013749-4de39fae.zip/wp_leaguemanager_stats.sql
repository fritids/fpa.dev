CREATE TABLE IF NOT EXISTS `wp_leaguemanager_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `fields` longtext NOT NULL,
  `league_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_leaguemanager_stats`;

# --------------------------------------------------------

