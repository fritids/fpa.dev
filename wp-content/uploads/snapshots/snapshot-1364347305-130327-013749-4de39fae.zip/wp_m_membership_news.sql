CREATE TABLE IF NOT EXISTS `wp_m_membership_news` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `newsitem` text,
  `newsdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_membership_news`;

# --------------------------------------------------------

