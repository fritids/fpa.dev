CREATE TABLE IF NOT EXISTS `wp_bp_user_blogs_blogmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_user_blogs_blogmeta`;
 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('1', '1', 'name', 'Freestyle Players Association'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('2', '1', 'description', 'Just another WordPress site'); 
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES ('3', '1', 'last_activity', '2013-03-26 21:30:06');
# --------------------------------------------------------

