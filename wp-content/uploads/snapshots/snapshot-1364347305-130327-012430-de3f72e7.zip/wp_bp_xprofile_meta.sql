CREATE TABLE IF NOT EXISTS `wp_bp_xprofile_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) NOT NULL,
  `object_type` varchar(150) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_bp_xprofile_meta`;
 
INSERT INTO `wp_bp_xprofile_meta` VALUES ('1', '2', 'field', 'default_visibility', 'public'); 
INSERT INTO `wp_bp_xprofile_meta` VALUES ('2', '2', 'field', 'allow_custom_visibility', 'allowed');
# --------------------------------------------------------

