CREATE TABLE IF NOT EXISTS `wp_leaguemanager_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` varchar(30) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `home_team` varchar(255) NOT NULL DEFAULT '0',
  `away_team` varchar(255) NOT NULL DEFAULT '0',
  `match_day` tinyint(4) NOT NULL DEFAULT '0',
  `location` varchar(100) NOT NULL DEFAULT '',
  `league_id` int(11) NOT NULL DEFAULT '0',
  `season` varchar(255) NOT NULL DEFAULT '',
  `home_points` varchar(30) DEFAULT NULL,
  `away_points` varchar(30) DEFAULT NULL,
  `winner_id` int(11) NOT NULL DEFAULT '0',
  `loser_id` int(11) NOT NULL DEFAULT '0',
  `post_id` int(11) NOT NULL DEFAULT '0',
  `final` varchar(150) NOT NULL DEFAULT '',
  `custom` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_leaguemanager_matches`;

# --------------------------------------------------------

