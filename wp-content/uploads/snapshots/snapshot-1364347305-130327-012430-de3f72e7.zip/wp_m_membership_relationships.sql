CREATE TABLE IF NOT EXISTS `wp_m_membership_relationships` (
  `rel_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT '0',
  `sub_id` bigint(20) DEFAULT '0',
  `level_id` bigint(20) DEFAULT '0',
  `startdate` datetime DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `order_instance` bigint(20) DEFAULT '0',
  `usinggateway` varchar(50) DEFAULT 'admin',
  PRIMARY KEY (`rel_id`),
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  KEY `usinggateway` (`usinggateway`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_membership_relationships`;

# --------------------------------------------------------

