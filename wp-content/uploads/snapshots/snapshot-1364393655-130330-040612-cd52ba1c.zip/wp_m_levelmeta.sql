CREATE TABLE IF NOT EXISTS `wp_m_levelmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_id` bigint(20) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_value` text,
  `meta_stamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `level_id` (`level_id`,`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_levelmeta`;
 
INSERT INTO `wp_m_levelmeta` VALUES ('1', '1', 'joining_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('2', '1', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('3', '1', 'associated_wp_role', 'subscriber', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('4', '2', 'joining_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('5', '2', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('6', '2', 'associated_wp_role', 'author', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('7', '3', 'joining_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('8', '3', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('9', '3', 'associated_wp_role', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('13', '4', 'joining_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('14', '4', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('15', '4', 'associated_wp_role', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('19', '5', 'joining_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('20', '5', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('21', '5', 'associated_wp_role', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('22', '6', 'joining_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('23', '6', 'leaving_ping', '', ''); 
INSERT INTO `wp_m_levelmeta` VALUES ('24', '6', 'associated_wp_role', '', '');
# --------------------------------------------------------

