CREATE TABLE IF NOT EXISTS `wp_rg_paypal_transaction` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `transaction_type` varchar(15) DEFAULT NULL,
  `subscription_id` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `parent_transaction_id` varchar(50) DEFAULT NULL,
  `is_renewal` tinyint(1) NOT NULL DEFAULT '0',
  `amount` decimal(19,2) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `txn_id` (`transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_rg_paypal_transaction`;

# --------------------------------------------------------

