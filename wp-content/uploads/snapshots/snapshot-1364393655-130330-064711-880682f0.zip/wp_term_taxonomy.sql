CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_term_taxonomy`;
 
INSERT INTO `wp_term_taxonomy` VALUES ('1', '1', 'category', '', '0', '3'); 
INSERT INTO `wp_term_taxonomy` VALUES ('2', '2', 'nav_menu', '', '0', '19'); 
INSERT INTO `wp_term_taxonomy` VALUES ('3', '3', 'resource-category', 'Applications', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('4', '4', 'resource-category', 'Judging Forms &amp; Templates', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('5', '5', 'resource-category', 'Press Releases &amp; Info', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('6', '6', 'resource-category', 'Resources for Tournament Organization', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('7', '7', 'tribe_events_cat', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('8', '8', 'category', '', '0', '3'); 
INSERT INTO `wp_term_taxonomy` VALUES ('12', '12', 'media-type', '', '0', '5'); 
INSERT INTO `wp_term_taxonomy` VALUES ('13', '13', 'media-type', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('11', '11', 'gallery-album', '', '0', '7'); 
INSERT INTO `wp_term_taxonomy` VALUES ('14', '14', 'difficulty-level', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('15', '15', 'difficulty-level', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('16', '16', 'move_type', '', '0', '7'); 
INSERT INTO `wp_term_taxonomy` VALUES ('17', '17', 'move_type', '', '0', '3'); 
INSERT INTO `wp_term_taxonomy` VALUES ('18', '18', 'move_type', '', '0', '3'); 
INSERT INTO `wp_term_taxonomy` VALUES ('19', '19', 'move_type', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('20', '20', 'move_type', '', '0', '2'); 
INSERT INTO `wp_term_taxonomy` VALUES ('21', '21', 'move_type', '', '0', '3'); 
INSERT INTO `wp_term_taxonomy` VALUES ('22', '22', 'move_type', '', '0', '3'); 
INSERT INTO `wp_term_taxonomy` VALUES ('23', '23', 'move-category', '', '0', '7'); 
INSERT INTO `wp_term_taxonomy` VALUES ('24', '24', 'nav_menu', '', '0', '5'); 
INSERT INTO `wp_term_taxonomy` VALUES ('25', '25', 'nav_menu', '', '0', '4');
# --------------------------------------------------------

