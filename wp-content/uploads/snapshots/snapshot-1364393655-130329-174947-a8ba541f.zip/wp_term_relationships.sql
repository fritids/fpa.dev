CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_term_relationships`;
 
INSERT INTO `wp_term_relationships` VALUES ('1', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('45', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('50', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('51', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('139', '8', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('43', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('44', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('46', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('47', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('48', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('49', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('62', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('153', '12', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('153', '11', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('63', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('66', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('68', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('67', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('70', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('73', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('82', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('84', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('119', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('121', '4', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('123', '7', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('134', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('137', '8', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('146', '11', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('141', '8', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('146', '12', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('166', '14', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('151', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('152', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('155', '12', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('155', '11', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('157', '12', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('157', '11', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('159', '12', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('159', '11', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('161', '13', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('161', '11', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('162', '13', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('162', '11', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('167', '15', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('173', '16', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('174', '16', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('175', '16', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('176', '16', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('177', '16', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('178', '16', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('179', '16', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('179', '23', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('178', '23', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('177', '23', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('176', '23', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('175', '23', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('174', '23', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('173', '23', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('179', '17', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('177', '17', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('174', '17', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('179', '20', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('175', '20', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('178', '18', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('176', '18', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('174', '18', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('179', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('176', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('178', '21', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('174', '21', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('173', '21', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('179', '22', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('176', '22', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('175', '22', '0');
# --------------------------------------------------------

