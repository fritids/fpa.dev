CREATE TABLE IF NOT EXISTS `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_rg_form_view`;
 
INSERT INTO `wp_rg_form_view` VALUES ('1', '2', '2013-03-25 16:09:55', '127.0.0.1', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('2', '1', '2013-03-28 15:35:04', '127.0.0.1', '2'); 
INSERT INTO `wp_rg_form_view` VALUES ('3', '1', '2013-03-28 22:06:33', '127.0.0.1', '3');
# --------------------------------------------------------

