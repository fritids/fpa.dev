CREATE TABLE IF NOT EXISTS `wp_p2pmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p2p_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `p2p_id` (`p2p_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_p2pmeta`;
 
INSERT INTO `wp_p2pmeta` VALUES ('1', '2', 'finish', '1'); 
INSERT INTO `wp_p2pmeta` VALUES ('2', '3', 'finish', '2'); 
INSERT INTO `wp_p2pmeta` VALUES ('3', '1', 'finish', '3'); 
INSERT INTO `wp_p2pmeta` VALUES ('4', '4', 'finish', '1'); 
INSERT INTO `wp_p2pmeta` VALUES ('5', '5', 'finish', '1'); 
INSERT INTO `wp_p2pmeta` VALUES ('8', '4', 'round', 'Finals'); 
INSERT INTO `wp_p2pmeta` VALUES ('9', '7', 'round', 'Semifinals'); 
INSERT INTO `wp_p2pmeta` VALUES ('10', '7', 'finish', '3');
# --------------------------------------------------------

