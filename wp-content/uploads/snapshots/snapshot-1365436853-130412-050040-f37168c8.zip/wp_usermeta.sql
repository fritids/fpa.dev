CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=133525 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_usermeta`;
 
INSERT INTO `wp_usermeta` VALUES ('1', '1', 'first_name', 'Ryan'); 
INSERT INTO `wp_usermeta` VALUES ('2', '1', 'last_name', 'Holmes'); 
INSERT INTO `wp_usermeta` VALUES ('3', '1', 'nickname', 'Rising Artistry'); 
INSERT INTO `wp_usermeta` VALUES ('4', '1', 'description', 'We designed and developed this. And it was so great!'); 
INSERT INTO `wp_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('10', '1', 'wp_capabilities', 'a:4:{s:13:"administrator";b:1;s:15:"membershipadmin";b:1;s:18:"M_add_subscription";b:1;s:10:"M_add_ping";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('11', '1', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `wp_usermeta` VALUES ('13', '1', 'show_welcome_panel', '0'); 
INSERT INTO `wp_usermeta` VALUES ('14', '1', 'wp_dashboard_quick_press_last_post_id', '313'); 
INSERT INTO `wp_usermeta` VALUES ('15', '1', 'managenav-menuscolumnshidden', 'a:3:{i:0;s:11:"link-target";i:1;s:3:"xfn";i:2;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES ('16', '1', 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'); 
INSERT INTO `wp_usermeta` VALUES ('17', '1', 'nav_menu_recently_edited', '2'); 
INSERT INTO `wp_usermeta` VALUES ('18', '1', 'wp_user-settings', 'hidetb=1&editor=tinymce&libraryContent=browse&imgsize=thumbnail&urlbutton=none&wplink=1'); 
INSERT INTO `wp_usermeta` VALUES ('19', '1', 'wp_user-settings-time', '1364511567'); 
INSERT INTO `wp_usermeta` VALUES ('20', '1', 'wpcf-group-form-toggle', 'a:8:{i:89;a:1:{s:29:"fieldset-about-freestyle-what";i:1;}i:109;a:4:{s:24:"fieldset-news-source-url";i:1;s:25:"fieldset-news-description";i:1;s:25:"fieldset-news-source-name";i:1;s:28:"fieldset-textfield-850554999";i:1;}i:144;a:8:{s:22:"fieldset-gallery-image";i:1;s:33:"gallery-image_conditional_display";i:1;s:39:"textarea-1696004032_conditional_display";i:1;s:27:"fieldset-gallery-media-type";i:1;s:28:"fieldset-gallery-video-embed";i:1;s:38:"textfield-83629395_conditional_display";i:1;s:25:"fieldset-gallery-video-id";i:1;s:23:"fieldset-vimeo-video-id";i:1;}i:164;a:4:{s:26:"fieldset-video-description";i:1;s:37:"video-description_conditional_display";i:1;s:23:"fieldset-vimeo-video-id";i:1;s:34:"vimeo-video-id_conditional_display";i:1;}i:95;a:5:{s:18:"fieldset-slide-rul";i:1;s:23:"fieldset-slide-btn-text";i:1;s:18:"fieldset-slide-url";i:1;s:20:"fieldset-slide-image";i:1;s:26:"fieldset-slide-description";i:1;}i:172;a:1:{s:26:"fieldset-video-description";i:1;}i:245;a:2:{s:29:"fieldset-subscription-details";i:1;s:29:"fieldset-membership-shortcode";i:1;}i:269;a:0:{}}'); 
INSERT INTO `wp_usermeta` VALUES ('21', '1', 'tribe_setDefaultNavMenuBoxes', '1'); 
INSERT INTO `wp_usermeta` VALUES ('22', '1', 'aim', ''); 
INSERT INTO `wp_usermeta` VALUES ('23', '1', 'yim', ''); 
INSERT INTO `wp_usermeta` VALUES ('24', '1', 'jabber', ''); 
INSERT INTO `wp_usermeta` VALUES ('25', '1', 'closedpostboxes_gallery-item', 'a:1:{i:0;s:14:"wpcf-marketing";}'); 
INSERT INTO `wp_usermeta` VALUES ('26', '1', 'metaboxhidden_gallery-item', 'a:2:{i:0;s:14:"wpcf-marketing";i:1;s:7:"slugdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('27', '1', 'meta-box-order_gallery-item', 'a:3:{s:4:"side";s:88:"wpcf-marketing,submitdiv,media-typediv,gallery-albumdiv,tagsdiv-gallery-tag,postimagediv";s:6:"normal";s:37:"gallery-item,page-description,slugdiv";s:8:"advanced";s:0:"";}'); 
INSERT INTO `wp_usermeta` VALUES ('28', '1', 'screen_layout_gallery-item', '2'); 
INSERT INTO `wp_usermeta` VALUES ('29', '1', 'last_activity', '2013-03-26 22:34:09'); 
INSERT INTO `wp_usermeta` VALUES ('30', '1', 'current-membershipwizard-step', '3'); 
INSERT INTO `wp_usermeta` VALUES ('31', '1', 'closedpostboxes_page', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('32', '1', 'metaboxhidden_page', 'a:6:{i:0;s:10:"postcustom";i:1;s:16:"commentstatusdiv";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";i:5;s:12:"revisionsdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('33', '1', 'current-membership-step', '34'); 
INSERT INTO `wp_usermeta` VALUES ('330', '1', 'using_gateway_5', 'paypalexpress'); 
INSERT INTO `wp_usermeta` VALUES ('329', '1', 'expire_current_5', '1396046965'); 
INSERT INTO `wp_usermeta` VALUES ('328', '1', 'start_current_5', '1364510965'); 
INSERT INTO `wp_usermeta` VALUES ('37', '1', '_membership_last_upgraded', '1364418900'); 
INSERT INTO `wp_usermeta` VALUES ('38', '1', '_membership_key', 'fb2275607f852c725b4e790c07b24e43'); 
INSERT INTO `wp_usermeta` VALUES ('336', '1', 'wpseo_metakey', ''); 
INSERT INTO `wp_usermeta` VALUES ('335', '1', 'wpseo_metadesc', ''); 
INSERT INTO `wp_usermeta` VALUES ('334', '1', 'wpseo_title', ''); 
INSERT INTO `wp_usermeta` VALUES ('333', '1', 'favorite_moves', 'Twirling Dirvish'); 
INSERT INTO `wp_usermeta` VALUES ('332', '1', 'twitter', ''); 
INSERT INTO `wp_usermeta` VALUES ('331', '1', 'googleplus', ''); 
INSERT INTO `wp_usermeta` VALUES ('327', '1', '_membership_expire_next', '2'); 
INSERT INTO `wp_usermeta` VALUES ('326', '1', 'action_shot_one', '/2013/03/360catch-beach1364602333.jpg'); 
INSERT INTO `wp_usermeta` VALUES ('325', '1', 'country_name', 'US'); 
INSERT INTO `wp_usermeta` VALUES ('337', '1', 'player_rank', ''); 
INSERT INTO `wp_usermeta` VALUES ('449', '27', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('450', '27', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('451', '27', 'nickname', 'fpa-admin'); 
INSERT INTO `wp_usermeta` VALUES ('452', '27', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('453', '27', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('454', '27', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('455', '27', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('456', '27', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('457', '27', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('458', '27', 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('459', '27', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('460', '27', 'user_meta_user_status', 'active'); 
INSERT INTO `wp_usermeta` VALUES ('461', '27', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `wp_usermeta` VALUES ('462', '27', 'start_current_2', '1364611022'); 
INSERT INTO `wp_usermeta` VALUES ('463', '27', 'expire_current_2', '1366339022'); 
INSERT INTO `wp_usermeta` VALUES ('464', '27', 'using_gateway_2', 'admin'); 
INSERT INTO `wp_usermeta` VALUES ('30269', '1', 'users_per_page', '100'); 
INSERT INTO `wp_usermeta` VALUES ('133524', '1', 'screen_layout_player', '2'); 
INSERT INTO `wp_usermeta` VALUES ('133523', '1', 'meta-box-order_player', 'a:3:{s:4:"side";s:41:"wpcf-marketing,submitdiv,page-description";s:6:"normal";s:69:"player-details,p2p-from-player_to_event,postcustom,wpseo_meta,slugdiv";s:8:"advanced";s:0:"";}'); 
INSERT INTO `wp_usermeta` VALUES ('133522', '1', 'metaboxhidden_player', 'a:3:{i:0;s:14:"wpcf-marketing";i:1;s:10:"postcustom";i:2;s:7:"slugdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('133521', '1', 'closedpostboxes_player', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('133516', '1', 'meta-box-order_tribe_events', 'a:3:{s:4:"side";s:73:"submitdiv,tribe_events_catdiv,Event Options,postimagediv,page-description";s:6:"normal";s:88:"Event Details,p2p-to-player_to_event,wpseo_meta,postexcerpt,postcustom,slugdiv,authordiv";s:8:"advanced";s:0:"";}'); 
INSERT INTO `wp_usermeta` VALUES ('133517', '1', 'screen_layout_tribe_events', '2'); 
INSERT INTO `wp_usermeta` VALUES ('133518', '1', 'closedpostboxes_tribe_events', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('133519', '1', 'metaboxhidden_tribe_events', 'a:4:{i:0;s:11:"postexcerpt";i:1;s:10:"postcustom";i:2;s:7:"slugdiv";i:3;s:9:"authordiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('133520', '1', 'edit_player_per_page', '200');
# --------------------------------------------------------

