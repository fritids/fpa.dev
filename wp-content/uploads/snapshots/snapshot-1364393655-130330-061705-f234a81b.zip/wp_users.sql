CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_users`;
 
INSERT INTO `wp_users` VALUES ('1', 'Rising Artistry', '$P$BPQpbwN5enpmDrt6vDbTGdFdKWv4OO0', 'rising-artistry', 'hello@risingartistry.com', '', '2013-02-25 22:43:18', '', '0', 'Ryan Holmes'); 
INSERT INTO `wp_users` VALUES ('21', 'Frank Freestyle', '$P$BkIDTZ0E6gQcqaCMnk8YvIDbCK0viY0', 'frank-freestyle', 'frank@freestyle.com', '', '2013-03-30 03:10:20', '', '0', 'Frank Freestyle'); 
INSERT INTO `wp_users` VALUES ('22', 'jammer', '$P$BM58Mh9O9pk/3v20m5MfS3Ht2KyF49.', 'jammer', 'rholmes.design@gmail.com', '', '2013-03-30 05:43:48', '', '0', 'jammer');
# --------------------------------------------------------

