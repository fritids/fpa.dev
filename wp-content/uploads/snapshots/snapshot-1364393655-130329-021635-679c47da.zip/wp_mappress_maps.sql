CREATE TABLE IF NOT EXISTS `wp_mappress_maps` (
  `mapid` int(11) NOT NULL AUTO_INCREMENT,
  `obj` longtext,
  PRIMARY KEY (`mapid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_mappress_maps`;
 
INSERT INTO `wp_mappress_maps` VALUES ('1', 'O:12:"Mappress_Map":9:{s:5:"mapid";N;s:5:"width";s:4:"100%";s:6:"height";s:3:"350";s:4:"zoom";i:16;s:6:"center";a:2:{s:3:"lat";d:41.7782610000000005356923793442547321319580078125;s:3:"lng";d:-71.3639620000000149957486428320407867431640625;}s:9:"mapTypeId";s:7:"roadmap";s:5:"title";s:13:"FPA Locations";s:7:"metaKey";N;s:4:"pois";a:1:{i:0;O:12:"Mappress_Poi":10:{s:7:"address";s:50:"25 Bullocks Point Avenue, Riverside, RI 02915, USA";s:4:"body";s:19:"Riverside, RI 02915";s:16:"correctedAddress";s:50:"25 Bullocks Point Avenue, Riverside, RI 02915, USA";s:6:"iconid";N;s:5:"point";a:2:{s:3:"lat";d:41.7782610000000005356923793442547321319580078125;s:3:"lng";d:-71.3639620000000149957486428320407867431640625;}s:4:"poly";N;s:3:"kml";N;s:5:"title";s:24:"25 Bullocks Point Avenue";s:4:"type";N;s:8:"viewport";a:2:{s:2:"sw";a:2:{s:3:"lat";d:41.77691201970849732560964184813201427459716796875;s:3:"lng";d:-71.365310980291496889549307525157928466796875;}s:2:"ne";a:2:{s:3:"lat";d:41.779609980291496640347759239375591278076171875;s:3:"lng";d:-71.36261301970853310194797813892364501953125;}}}}}');
# --------------------------------------------------------

