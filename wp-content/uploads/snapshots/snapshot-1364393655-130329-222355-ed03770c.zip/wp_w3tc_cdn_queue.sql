CREATE TABLE IF NOT EXISTS `wp_w3tc_cdn_queue` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `local_path` varchar(500) NOT NULL DEFAULT '',
  `remote_path` varchar(500) NOT NULL DEFAULT '',
  `command` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - Upload, 2 - Delete, 3 - Purge',
  `last_error` varchar(150) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `path` (`local_path`,`remote_path`),
  KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_w3tc_cdn_queue`;
 
INSERT INTO `wp_w3tc_cdn_queue` VALUES ('1', '/Users/Holmes/Sites/fpa.dev/wp-content/cache/tmp/.htaccess', '.htaccess', '1', 'Empty host.', '2013-03-25 15:43:26');
# --------------------------------------------------------

