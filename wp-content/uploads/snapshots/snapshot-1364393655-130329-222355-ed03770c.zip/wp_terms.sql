CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_terms`;
 
INSERT INTO `wp_terms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `wp_terms` VALUES ('2', 'Main Navigation', 'main-navigation', '0'); 
INSERT INTO `wp_terms` VALUES ('3', 'Applications', 'applications', '0'); 
INSERT INTO `wp_terms` VALUES ('4', 'Judging', 'judging', '0'); 
INSERT INTO `wp_terms` VALUES ('5', 'Press', 'press', '0'); 
INSERT INTO `wp_terms` VALUES ('6', 'Tournament Organization', 'tournament-organization', '0'); 
INSERT INTO `wp_terms` VALUES ('7', 'Freestyle Event', 'freestyle-event', '0'); 
INSERT INTO `wp_terms` VALUES ('8', 'Tournaments', 'tournaments', '0'); 
INSERT INTO `wp_terms` VALUES ('12', 'Photos', 'photos', '0'); 
INSERT INTO `wp_terms` VALUES ('11', 'FPA Worlds Berlin', 'fpa-worlds-berlin', '0'); 
INSERT INTO `wp_terms` VALUES ('13', 'Videos', 'videos', '0'); 
INSERT INTO `wp_terms` VALUES ('14', 'Basic', 'basic', '0'); 
INSERT INTO `wp_terms` VALUES ('15', 'Advanced', 'advanced', '0'); 
INSERT INTO `wp_terms` VALUES ('16', 'Catches', 'catches', '0'); 
INSERT INTO `wp_terms` VALUES ('17', 'Throws', 'throws', '0'); 
INSERT INTO `wp_terms` VALUES ('18', 'Pulls', 'pulls', '0'); 
INSERT INTO `wp_terms` VALUES ('19', 'Shoots/Hoops', 'shoots-hoops', '0'); 
INSERT INTO `wp_terms` VALUES ('20', 'Delay/Flat', 'delayflat', '0'); 
INSERT INTO `wp_terms` VALUES ('21', 'Technical', 'technical', '0'); 
INSERT INTO `wp_terms` VALUES ('22', 'Tipping', 'tipping', '0'); 
INSERT INTO `wp_terms` VALUES ('23', 'Featured', 'featured', '0'); 
INSERT INTO `wp_terms` VALUES ('24', 'Footer Navigation', 'footer-navigation', '0');
# --------------------------------------------------------

