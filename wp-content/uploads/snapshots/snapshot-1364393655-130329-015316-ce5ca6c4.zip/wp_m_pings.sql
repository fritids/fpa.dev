CREATE TABLE IF NOT EXISTS `wp_m_pings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pingname` varchar(250) DEFAULT NULL,
  `pingurl` varchar(250) DEFAULT NULL,
  `pinginfo` text,
  `pingtype` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_pings`;

# --------------------------------------------------------

