CREATE TABLE IF NOT EXISTS `wp_m_coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) DEFAULT '0',
  `couponcode` varchar(250) DEFAULT NULL,
  `discount` decimal(11,2) DEFAULT '0.00',
  `discount_type` varchar(5) DEFAULT NULL,
  `discount_currency` varchar(5) DEFAULT NULL,
  `coupon_startdate` datetime DEFAULT NULL,
  `coupon_enddate` datetime DEFAULT NULL,
  `coupon_sub_id` bigint(20) DEFAULT '0',
  `coupon_uses` int(11) DEFAULT '0',
  `coupon_used` int(11) DEFAULT '0',
  `coupon_apply_to` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `couponcode` (`couponcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_coupons`;

# --------------------------------------------------------

