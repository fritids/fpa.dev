CREATE TABLE IF NOT EXISTS `wp_m_membership_relationships` (
  `rel_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT '0',
  `sub_id` bigint(20) DEFAULT '0',
  `level_id` bigint(20) DEFAULT '0',
  `startdate` datetime DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `order_instance` bigint(20) DEFAULT '0',
  `usinggateway` varchar(50) DEFAULT 'admin',
  PRIMARY KEY (`rel_id`),
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  KEY `usinggateway` (`usinggateway`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_membership_relationships`;
 
INSERT INTO `wp_m_membership_relationships` VALUES ('1', '1', '5', '6', '2013-03-27 17:15:00', '2013-03-28 22:49:25', '2014-03-28 22:49:25', '1', 'paypalexpress'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('2', '2', '2', '3', '2013-03-27 17:55:43', '2013-03-27 17:55:43', '2013-04-16 17:55:43', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('3', '3', '2', '3', '2013-03-28 00:23:35', '2013-03-28 00:23:35', '2013-04-17 00:23:35', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('4', '4', '2', '3', '2013-03-28 14:02:19', '2013-03-28 14:02:19', '2013-04-17 14:02:19', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('5', '5', '2', '3', '2013-03-28 14:07:45', '2013-03-28 14:07:45', '2013-04-17 14:07:45', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('6', '6', '2', '3', '2013-03-28 14:09:49', '2013-03-28 14:09:49', '2013-04-17 14:09:49', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('7', '7', '2', '3', '2013-03-28 14:20:00', '2013-03-28 14:20:00', '2013-04-17 14:20:00', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('8', '8', '2', '3', '2013-03-28 14:51:15', '2013-03-28 14:51:15', '2013-04-17 14:51:15', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('9', '9', '2', '3', '2013-03-28 14:56:33', '2013-03-28 14:56:33', '2013-04-17 14:56:33', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('10', '10', '2', '3', '2013-03-28 15:01:22', '2013-03-28 15:01:22', '2013-04-17 15:01:22', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('11', '11', '2', '3', '2013-03-28 15:15:02', '2013-03-28 15:15:02', '2013-04-17 15:15:02', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('12', '12', '2', '3', '2013-03-28 17:12:41', '2013-03-28 17:12:41', '2013-04-17 17:12:41', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('13', '13', '2', '3', '2013-03-28 17:27:39', '2013-03-28 17:27:39', '2013-04-17 17:27:39', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('14', '14', '2', '3', '2013-03-28 17:30:40', '2013-03-28 17:30:40', '2013-04-17 17:30:40', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('15', '15', '2', '3', '2013-03-28 17:31:47', '2013-03-28 17:31:47', '2013-04-17 17:31:47', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('16', '16', '2', '3', '2013-03-28 17:32:50', '2013-03-28 17:32:50', '2013-04-17 17:32:50', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('17', '17', '2', '3', '2013-03-28 17:33:23', '2013-03-28 17:33:23', '2013-04-17 17:33:23', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('18', '18', '2', '3', '2013-03-28 17:33:57', '2013-03-28 17:33:57', '2013-04-17 17:33:57', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('19', '19', '2', '3', '2013-03-28 17:36:44', '2013-03-28 17:36:44', '2013-04-17 17:36:44', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('20', '20', '2', '3', '2013-03-28 17:37:19', '2013-03-28 17:37:19', '2013-04-17 17:37:19', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('21', '21', '5', '6', '2013-03-29 23:17:13', '2013-03-29 23:17:13', '2014-03-29 23:17:13', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('22', '23', '2', '3', '2013-03-30 01:24:16', '2013-03-30 01:24:16', '2013-04-19 01:24:16', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('23', '24', '2', '3', '2013-03-30 01:29:53', '2013-03-30 01:29:53', '2013-04-19 01:29:53', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('24', '24', '4', '5', '2013-03-30 01:31:06', '2013-03-30 01:31:06', '2014-03-30 01:31:06', '1', 'paypalexpress'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('25', '25', '2', '3', '2013-03-30 01:46:53', '2013-03-30 01:46:53', '2013-04-19 01:46:53', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('26', '25', '3', '4', '2013-03-30 01:48:07', '2013-03-30 01:48:07', '2014-03-30 01:48:07', '1', 'paypalexpress'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('27', '26', '2', '3', '2013-03-30 01:52:02', '2013-03-30 01:52:02', '2013-04-19 01:52:02', '1', 'admin'); 
INSERT INTO `wp_m_membership_relationships` VALUES ('28', '27', '2', '3', '2013-03-30 02:37:02', '2013-03-30 02:37:02', '2013-04-19 02:37:02', '1', 'admin');
# --------------------------------------------------------

