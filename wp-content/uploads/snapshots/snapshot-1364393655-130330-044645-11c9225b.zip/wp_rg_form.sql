CREATE TABLE IF NOT EXISTS `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_rg_form`;
 
INSERT INTO `wp_rg_form` VALUES ('1', 'Contact Us', '2013-02-28 19:56:35', '1'); 
INSERT INTO `wp_rg_form` VALUES ('2', 'Join FPA', '2013-03-01 20:36:13', '1');
# --------------------------------------------------------

