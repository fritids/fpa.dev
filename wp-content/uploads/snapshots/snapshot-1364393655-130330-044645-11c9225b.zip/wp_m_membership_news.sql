CREATE TABLE IF NOT EXISTS `wp_m_membership_news` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `newsitem` text,
  `newsdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_membership_news`;
 
INSERT INTO `wp_m_membership_news` VALUES ('1', '<strong>Rising Artistry</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-27 17:15:00'); 
INSERT INTO `wp_m_membership_news` VALUES ('2', '<strong>themarblery</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-27 17:55:43'); 
INSERT INTO `wp_m_membership_news` VALUES ('3', '<strong>HillBillyJones</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 00:23:35'); 
INSERT INTO `wp_m_membership_news` VALUES ('4', '<strong>boynamedsue</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 14:02:19'); 
INSERT INTO `wp_m_membership_news` VALUES ('5', '<strong>markyshamp</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 14:07:45'); 
INSERT INTO `wp_m_membership_news` VALUES ('6', '<strong>finkle</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 14:09:49'); 
INSERT INTO `wp_m_membership_news` VALUES ('7', '<strong>smoger</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 14:20:00'); 
INSERT INTO `wp_m_membership_news` VALUES ('8', '<strong>jingle</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 14:51:15'); 
INSERT INTO `wp_m_membership_news` VALUES ('9', '<strong>pickle</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 14:56:33'); 
INSERT INTO `wp_m_membership_news` VALUES ('10', '<strong>heldme</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 15:01:22'); 
INSERT INTO `wp_m_membership_news` VALUES ('11', '<strong>asdasdfasdf</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 15:15:02'); 
INSERT INTO `wp_m_membership_news` VALUES ('12', '<strong>korichace</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 17:12:41'); 
INSERT INTO `wp_m_membership_news` VALUES ('13', '<strong>blues</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 17:27:39'); 
INSERT INTO `wp_m_membership_news` VALUES ('14', '<strong>table</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 17:30:40'); 
INSERT INTO `wp_m_membership_news` VALUES ('15', '<strong>smirk</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 17:31:48'); 
INSERT INTO `wp_m_membership_news` VALUES ('16', '<strong>delia</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 17:32:50'); 
INSERT INTO `wp_m_membership_news` VALUES ('17', '<strong>parker</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 17:33:23'); 
INSERT INTO `wp_m_membership_news` VALUES ('18', '<strong>gregg</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 17:33:57'); 
INSERT INTO `wp_m_membership_news` VALUES ('19', '<strong>billcamel</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 17:36:44'); 
INSERT INTO `wp_m_membership_news` VALUES ('20', '<strong>rains</strong> has joined level <strong>Basic</strong> on subscription <strong>Basic</strong>', '2013-03-28 17:37:19'); 
INSERT INTO `wp_m_membership_news` VALUES ('21', '<strong>Rising Artistry</strong> has moved from level <strong>Basic</strong> on subscription <strong>Basic</strong> to level <strong>Platinum</strong> on subscription <strong>Platinum</strong>', '2013-03-28 22:49:25'); 
INSERT INTO `wp_m_membership_news` VALUES ('22', '<strong>Frank Freestyle</strong> has joined level <strong>Platinum</strong> on subscription <strong>Platinum</strong>', '2013-03-29 23:17:13');
# --------------------------------------------------------

