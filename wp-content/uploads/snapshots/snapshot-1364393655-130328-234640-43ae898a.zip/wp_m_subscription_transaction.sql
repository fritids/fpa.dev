CREATE TABLE IF NOT EXISTS `wp_m_subscription_transaction` (
  `transaction_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_subscription_ID` bigint(20) NOT NULL DEFAULT '0',
  `transaction_user_ID` bigint(20) NOT NULL DEFAULT '0',
  `transaction_sub_ID` bigint(20) DEFAULT '0',
  `transaction_paypal_ID` varchar(30) DEFAULT NULL,
  `transaction_payment_type` varchar(20) DEFAULT NULL,
  `transaction_stamp` bigint(35) NOT NULL DEFAULT '0',
  `transaction_total_amount` bigint(20) DEFAULT NULL,
  `transaction_currency` varchar(35) DEFAULT NULL,
  `transaction_status` varchar(35) DEFAULT NULL,
  `transaction_duedate` date DEFAULT NULL,
  `transaction_gateway` varchar(50) DEFAULT NULL,
  `transaction_note` text,
  `transaction_expires` datetime DEFAULT NULL,
  PRIMARY KEY (`transaction_ID`),
  KEY `transaction_gateway` (`transaction_gateway`),
  KEY `transaction_subscription_ID` (`transaction_subscription_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_subscription_transaction`;

# --------------------------------------------------------

