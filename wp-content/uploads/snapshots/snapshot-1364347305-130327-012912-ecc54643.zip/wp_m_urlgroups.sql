CREATE TABLE IF NOT EXISTS `wp_m_urlgroups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(250) DEFAULT NULL,
  `groupurls` text,
  `isregexp` int(11) DEFAULT '0',
  `stripquerystring` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_urlgroups`;

# --------------------------------------------------------

