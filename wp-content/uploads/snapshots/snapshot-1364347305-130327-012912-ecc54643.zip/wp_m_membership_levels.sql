CREATE TABLE IF NOT EXISTS `wp_m_membership_levels` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_title` varchar(250) DEFAULT NULL,
  `level_slug` varchar(250) DEFAULT NULL,
  `level_active` int(11) DEFAULT '0',
  `level_count` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_membership_levels`;
 
INSERT INTO `wp_m_membership_levels` VALUES ('3', 'Free', 'free', '1', '0'); 
INSERT INTO `wp_m_membership_levels` VALUES ('4', 'Jammer', 'jammer', '1', '0'); 
INSERT INTO `wp_m_membership_levels` VALUES ('5', 'Competitor', 'competitor', '1', '0'); 
INSERT INTO `wp_m_membership_levels` VALUES ('6', 'Platinum', 'platinum', '1', '0'); 
INSERT INTO `wp_m_membership_levels` VALUES ('7', 'Visitors', 'visitors', '1', '0');
# --------------------------------------------------------

