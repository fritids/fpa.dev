CREATE TABLE IF NOT EXISTS `wp_m_subscriptions_levels` (
  `sub_id` bigint(20) DEFAULT NULL,
  `level_id` bigint(20) DEFAULT NULL,
  `level_period` int(11) DEFAULT NULL,
  `sub_type` varchar(20) DEFAULT NULL,
  `level_price` decimal(11,2) DEFAULT '0.00',
  `level_currency` varchar(5) DEFAULT NULL,
  `level_order` bigint(20) DEFAULT '0',
  `level_period_unit` varchar(1) DEFAULT 'd',
  KEY `sub_id` (`sub_id`),
  KEY `level_id` (`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_subscriptions_levels`;
 
INSERT INTO `wp_m_subscriptions_levels` VALUES ('3', '4', '20', 'serial', '0.00', 'USD', '1', 'd'); 
INSERT INTO `wp_m_subscriptions_levels` VALUES ('4', '5', '20', 'serial', '0.00', 'USD', '1', 'd'); 
INSERT INTO `wp_m_subscriptions_levels` VALUES ('5', '6', '20', 'serial', '0.00', 'USD', '1', 'd'); 
INSERT INTO `wp_m_subscriptions_levels` VALUES ('2', '3', '20', 'indefinite', '0.00', '', '1', 'd');
# --------------------------------------------------------

