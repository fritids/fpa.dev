CREATE TABLE IF NOT EXISTS `wp_mappress_posts` (
  `postid` int(11) NOT NULL DEFAULT '0',
  `mapid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`postid`,`mapid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_mappress_posts`;
 
INSERT INTO `wp_mappress_posts` VALUES ('19', '1');
# --------------------------------------------------------

