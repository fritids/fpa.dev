CREATE TABLE IF NOT EXISTS `wp_m_communications` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) DEFAULT NULL,
  `message` text,
  `periodunit` int(11) DEFAULT NULL,
  `periodtype` varchar(5) DEFAULT NULL,
  `periodprepost` varchar(5) DEFAULT NULL,
  `lastupdated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `active` int(11) DEFAULT '0',
  `periodstamp` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_communications`;

# --------------------------------------------------------

