CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_users`;
 
INSERT INTO `wp_users` VALUES ('1', 'Rising Artistry', '$P$BPQpbwN5enpmDrt6vDbTGdFdKWv4OO0', 'rising-artistry', 'hello@risingartistry.com', '', '2013-02-25 22:43:18', '', '0', 'Ryan Holmes'); 
INSERT INTO `wp_users` VALUES ('21', 'Frank Freestyle', '$P$BkIDTZ0E6gQcqaCMnk8YvIDbCK0viY0', 'frank-freestyle', 'frank@freestyle.com', '', '2013-03-30 03:10:20', '', '0', 'Frank Freestyle'); 
INSERT INTO `wp_users` VALUES ('22', 'testaccount', '$P$BzBERzSTskThXYGnCJN0f9beDdaC3z1', 'testaccount', 'rholmes.design@gmail.com', '', '2013-03-30 05:20:55', '', '0', 'testaccount'); 
INSERT INTO `wp_users` VALUES ('23', 'betaaccount', '$P$B1NTbsWRh6snyfC6G/tING4fB1CATK.', 'betaaccount', 'beta@beta.com', '', '2013-03-30 05:24:16', '', '0', 'betaaccount'); 
INSERT INTO `wp_users` VALUES ('24', 'competitor-test', '$P$BxwJ/BKBdSe2TTS7VGBAvfGL255zYc0', 'competitor-test', 'test@test.com', '', '2013-03-30 05:29:53', '', '0', 'competitor-test'); 
INSERT INTO `wp_users` VALUES ('25', 'jammer', '$P$Bl9YDBX/M/HbRj9wvUCfo9cUhOehFA0', 'jammer', 'jammer@jam.com', '', '2013-03-30 05:46:53', '', '0', 'jammer'); 
INSERT INTO `wp_users` VALUES ('26', 'basic', '$P$BH9N/J6f8osdFjPzHAdivhulcjjqmI1', 'basic', 'basc@asdf.com', '', '2013-03-30 05:52:02', '', '0', 'basic'); 
INSERT INTO `wp_users` VALUES ('27', 'fpa-admin', '$P$Bi76U0sIkwvzVswOgJWs0vquCrh/rI0', 'fpa-admin', 'fpa@fpa.com', '', '2013-03-30 06:37:01', '', '0', 'fpa-admin');
# --------------------------------------------------------

