CREATE TABLE IF NOT EXISTS `wp_m_subscriptions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(200) DEFAULT NULL,
  `sub_active` int(11) DEFAULT '0',
  `sub_public` int(11) DEFAULT '0',
  `sub_count` bigint(20) DEFAULT '0',
  `sub_description` text,
  `sub_pricetext` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_m_subscriptions`;
 
INSERT INTO `wp_m_subscriptions` VALUES ('2', 'Basic', '1', '1', '24', '<ul>\r\n	<li>FPA Membership</li>\r\n	<li>Player Profile</li>\r\n</ul>', '$0'); 
INSERT INTO `wp_m_subscriptions` VALUES ('3', 'Jammer', '1', '1', '1', '<ul>\r\n	<li>All the features of \\"Basic\\"</li>\r\n	<li><span style=\\"line-height: 13px;\\">2 Professional Discs with Collectible Design</span></li>\r\n	<li>Tournament DVD</li>\r\n	<li>Whiz Ring</li>\r\n	<li>FPA Voting Rights</li>\r\n</ul>', '$10'); 
INSERT INTO `wp_m_subscriptions` VALUES ('4', 'Competitor', '1', '1', '1', '<ul>\r\n	<li><span style=\\"line-height: 13px;\\">All the features of \\"Jammer\\"</span></li>\r\n	<li>Become eligiable to compete in FPA-sanctioned events</li>\r\n</ul>', '$25'); 
INSERT INTO `wp_m_subscriptions` VALUES ('5', 'Platinum', '1', '1', '2', '<ul>\r\n	<li><span style=\\"line-height: 13px;\\">All the features of \\"Competitor\\"</span></li>\r\n	<li>Special Recognition &amp; Insider Status</li>\r\n</ul>', '$100');
# --------------------------------------------------------

